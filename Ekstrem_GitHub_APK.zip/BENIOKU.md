# Ekstrem — GitHub ile APK derleme

1. GitHub'da yeni, **private** bir depo aç (ör. `ekstrem`).
2. Bu klasörün içeriğini (gizli `.github` klasörü dahil) depoya yükle.
   Web arayüzünde: "Add file → Upload files" ile sürükle bırak. `.github` klasörü
   görünmüyorsa dosya gezgininde gizli dosyaları göster.
3. Depoda **Actions** sekmesi → "APK oluştur" → **Run workflow**.
4. ~5 dakika sonra işin sayfasında **Artifacts → Ekstrem-apk** zip'ini indir,
   içindeki `app-debug.apk` dosyasını telefona at ve kur.

Kaynak kod `src/` klasöründe. Değişiklik yaparsan:
`npm i pdfjs-dist@3.11.174 && python3 src/build.py` ile `www/index.html` yeniden üretilir
(build.py'yi src klasörü içinde, node_modules erişilebilir şekilde çalıştır).
